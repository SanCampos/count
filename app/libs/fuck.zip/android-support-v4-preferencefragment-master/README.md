android-support-v4-preferencefragment
=====================================

Unofficial PreferenceFragment compatibility layer for Android 1.6 and up. Includes resources so add this as a library project to your project.